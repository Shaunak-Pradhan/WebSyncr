﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DevPortal.Models
{
    public enum UserRole
    {
        SuperAdmin = 1,
        Admin = 2,
    }
}