﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DevPortal.Models
{
    public class Placeholder
    {
        public string Title { get; set; }
        public string HeadTag { get; set; }
        public string Body { get; set; }
        public string Footer { get; set; }
        public string Text { get; set; }
        public string Text2 { get; set; }
        public string Text3 { get; set; }
        public string Text4 { get; set; }
        public string Text5 { get; set; }
    }
}