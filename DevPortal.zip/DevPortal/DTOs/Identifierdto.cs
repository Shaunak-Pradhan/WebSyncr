﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DevPortal.DTOs
{
    public class Identifierdto : Classdto
    {
        public string ID { get; set; }
    }
}