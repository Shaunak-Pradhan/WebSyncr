﻿using DevPortal.Services.Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DevPortal.Services.Implementation.File
{
    public class DeleteFileService : IDeleteFileService
    {
    }
}