﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DevPortal.Models
{
    public class DataBlockTags
    {
        public string section { set; get; }
        public string head { set; get; }
        public string body { set; get; }
    }
}