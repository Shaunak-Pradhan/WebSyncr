<html>
                               <head>
                                  <meta charset='utf-8'>
                                  <title>script</title>
                               </head>
                               <font color='#A6ACAF' size='5'>
                                  <marquee><b><i>Some Text</i></b></marquee>
                               </font>
                               <body background='' link='white' alink='blue' vlink='#F8F8FF' >
                                  //background image <br /> <font face='Lato' size='5'><img src='CUsers\vijayakumarPictureslogo.jpg' height='50px' width='100px'></font>//logo image <font face='cinzel' size='4'> <a href='#'>HOME</a> &n bsp; &nbs p; <a href='#'>VIDEOS</a> <a href='#'>ARTICLES</a> <a href='#'>BLOG</a> <a href='#'>ABOUT US</a> </font> <br /><br /><br /><br /> <br /> <br /> 
                                  <h1 align='center'> <font color='#F0B27A' size='9' id='heading'> This is @ Text <br/> </font>Same 3rd Text</h1>
                                  <h3 align='center'>
                                  <font face='Lato' color='red' size='3'> teXT 4 </font> <br /><br /><br /><br /><br /><br/><br/><br/><br/> 
                                  <hr width='1500px'>
                                  <footer id='footer'>
                                     <center> <b> <font face='cinzel' size='4'> <a href ='#'>About Us| <a href ='#'>Contact Us | <a href ='#'> Privacy Policy | <a href ='#'> Terms | <a href ='#'>Media Kit | <a href ='#'> Sitemap | <a href ='#'> Report a Bug | <a href ='#'> FAQ Partners</a><br/> <a href ='#'>C# Tutorials| <a href ='#'> Common Interview Questions| <a href ='#'> Stories | <a href ='#'>Consultants | <a href ='#'> Ideas | <a href ='#'> Certifications </a><br/><br/> <font color='#FF0000'>all@copyrights 2020</font> </font> </b> </center>
                                  </footer>
                               </body>
                            </html>