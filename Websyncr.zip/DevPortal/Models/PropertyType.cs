﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DevPortal.Models
{
    public enum PropertyType
    {
        Text = 1,
        HMTL = 2,
        Image = 3,
        Video = 4
    }
}